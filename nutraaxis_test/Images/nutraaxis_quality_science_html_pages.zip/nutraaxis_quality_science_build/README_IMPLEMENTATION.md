# NutraAxis Our Science / Our Quality HTML Build

This package contains responsive HTML/CSS pages built from the supplied OurScience and OurQuality reference images.

## Files

- `rendered_pages/Our_Science.html` — full page using the Archive-derived header/footer template with the new `<main>` content inserted.
- `rendered_pages/Our_Quality.html` — full page using the Archive-derived header/footer template with the new `<main>` content inserted.
- `rendered_pages/Our_Science_standalone.html` — standalone preview version.
- `rendered_pages/Our_Quality_standalone.html` — standalone preview version.
- `main_snippets/our_science_main_snippet.html` — paste this between `<main>` and `</main>` for the Our Science page.
- `main_snippets/our_quality_main_snippet.html` — paste this between `<main>` and `</main>` for the Our Quality page.
- `assets/` — optional standalone SVG graphics extracted from the page concepts for reuse.
- `reference_images/` — the user-provided design references used for the build.

## Responsiveness

The CSS is scoped under `.nx-page` and includes breakpoints for:

- Desktop: full two-column hero and section layouts.
- iPad/tablet: stacked hero with preserved visual hierarchy.
- Mobile: single-column cards, full-width CTAs, horizontally scrollable process graphics so the workflow stays readable.

## Implementation note

The snippets include their own `<style>` block because the request asked for CSS/style tags where necessary. All styles are scoped to `.nx-page` to avoid affecting the persistent Archive navigation, header, and footer.
